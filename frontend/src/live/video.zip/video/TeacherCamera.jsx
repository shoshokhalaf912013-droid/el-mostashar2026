import { useRef, useEffect, useState } from "react"

export default function TeacherCamera({ track }) {

  const videoRef = useRef()

  const [mode, setMode] = useState("small")
  const [position, setPosition] = useState({ x: 50, y: 50 })
  const [dragging, setDragging] = useState(false)
  const dragOffset = useRef({ x: 0, y: 0 })

  // =========================
  // 🎥 LiveKit Attach
  // =========================
  useEffect(() => {

    if (track && videoRef.current) {

      const element = track.attach()

      videoRef.current.innerHTML = ""
      videoRef.current.appendChild(element)

      element.style.width = "100%"
      element.style.height = "100%"
      element.style.objectFit = "cover"
      element.autoplay = true
      element.muted = true
      element.playsInline = true
    }

    return () => {
      if (track) {
        track.detach().forEach(el => el.remove())
      }
    }

  }, [track])

  // =========================
  // 🎯 Double Click (3 Modes)
  // =========================
  const handleDoubleClick = () => {
    if (mode === "small") setMode("medium")
    else if (mode === "medium") setMode("full")
    else setMode("small")
  }

  // =========================
  // 🖱️ Drag
  // =========================
  const handleMouseDown = (e) => {
    if (mode === "full") return

    setDragging(true)

    dragOffset.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y
    }
  }

  const handleMouseMove = (e) => {
    if (!dragging) return

    setPosition({
      x: e.clientX - dragOffset.current.x,
      y: e.clientY - dragOffset.current.y
    })
  }

  const handleMouseUp = () => {
    setDragging(false)
  }

  useEffect(() => {
    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("mouseup", handleMouseUp)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseup", handleMouseUp)
    }
  }, [dragging])

  // =========================
  // 🎨 Styles
  // =========================
  let style = {}

  if (mode === "small") {
    style = {
      width: "220px",
      height: "150px",
      position: "fixed",
      top: position.y,
      left: position.x,
      zIndex: 9999,
      cursor: "grab",
      borderRadius: "12px",
      overflow: "hidden",
      background: "#000"
    }
  }

  if (mode === "medium") {
    style = {
      width: "420px",
      height: "280px",
      position: "fixed",
      top: position.y,
      left: position.x,
      zIndex: 9999,
      cursor: "grab",
      borderRadius: "12px",
      overflow: "hidden",
      background: "#000"
    }
  }

  if (mode === "full") {
    style = {
      width: "100%",
      height: "100%",
      position: "fixed",
      top: 0,
      left: 0,
      zIndex: 9999,
      background: "#000"
    }
  }

  // =========================
  // 🧱 Render
  // =========================
  return (
    <div
      style={style}
      onDoubleClick={handleDoubleClick}
      onMouseDown={handleMouseDown}
    >

      {/* ✅ لو فيه فيديو */}
      {track ? (
        <div
          ref={videoRef}
          style={{ width: "100%", height: "100%" }}
        />
      ) : (
        // ❗ Placeholder بدل الشاشة السودا
        <div style={{
          width: "100%",
          height: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          color: "#fff",
          fontSize: "18px",
          background: "#111"
        }}>
          🎥 No Camera
        </div>
      )}

    </div>
  )
}